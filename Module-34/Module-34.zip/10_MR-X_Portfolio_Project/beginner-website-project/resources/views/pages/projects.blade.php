@extends('app')
@section('content')
    @include('components.project-list')
    @include('components.call-action')
@endsection
