@extends('app')
@section('content')
    @include('components.experience')
    @include('components.education')
    @include('components.professional-skills')
    @include('components.languages')
@endsection
