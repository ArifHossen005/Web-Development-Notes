
Steps:
1.  .env file er modde smtp diben 
MAIL_MAILER=smtp
MAIL_HOST=
MAIL_PORT=465
MAIL_USERNAME= 
MAIL_PASSWORD=
MAIL_ENCRYPTION= 
MAIL_FROM_ADDRESS=
MAIL_FROM_NAME="${APP_NAME}"

2. mysql e imort korben 

finalexam.sql    (jeta project er moddei diyechi)


# Customer Account
- **Name**: Sohag khan 
- **Email**: arifsohag2700@gmail.com
- **Password**: 12345678

# Admin Account
- **Name**: Arif Hossen
- **Email**: arifsohag2500@gmail.com
- **Password**: 12345678






