<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>My Bookings</h2>
    <div class="rounded p-2 shadow">
        <div class="mt-4">
            <h3>Current Bookings</h3>
            <hr>
            <table class="table">
                <thead>
                    <tr>
                        <th>Car</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Total Cost</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $currentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->car->brand); ?> - <?php echo e($booking->car->car_type); ?></td>
                            <td><?php echo e($booking->start_date); ?></td>
                            <td><?php echo e($booking->end_date); ?></td>
                            <td>$<?php echo e($booking->total_cost); ?></td>
                            <td>
                                <?php if(now()->lt($booking->start_date)): ?>
                                    <div class="d-flex flex-wrap">

                                        <?php if($booking->status == 'Pending'): ?>
                                            <div class="p-2">
                                                <form action="<?php echo e(route('frontend.rentals.update', $booking->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <input name="status" type="hidden" value="Ongoing">
                                                    <button class="btn btn-sm btn-outline-success" type="submit">Ongoing</button>
                                                </form>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($booking->status == 'Ongoing'): ?>
                                            <div class="p-2">
                                                <form action="<?php echo e(route('frontend.rentals.update', $booking->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <input name="status" type="hidden" value="Completed">
                                                    <button class="btn btn-sm btn-outline-success" type="submit">Completed</button>
                                                </form>
                                            </div>
                                        <?php endif; ?>

                                        <div class="p-2">
                                            <form action="<?php echo e(route('frontend.rentals.destroy', $booking->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input name="status" type="hidden" value="Canceled">
                                                <button class="btn btn-sm btn-outline-danger" type="submit">Cancel Booking</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <div class="col-4">
                                            <span class="text-danger">Ride already started</span>
                                        </div>
                                        <div class="col-4">
                                            <form action="<?php echo e(route('frontend.rentals.update', $booking->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <input name="status" type="hidden" value="Completed">
                                                <button class="btn btn-sm btn-outline-success" type="submit">Completed</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-5">
            <h3>Past Bookings</h3>
            <hr>
            <table class="table">
                <thead>
                    <tr>
                        <th>Car</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Total Cost</th>
                        <th>Status Was</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pastBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->car->brand); ?> - <?php echo e($booking->car->car_type); ?></td>
                            <td><?php echo e($booking->start_date); ?></td>
                            <td><?php echo e($booking->end_date); ?></td>
                            <td>$<?php echo e($booking->total_cost); ?></td>
                            <td>
                                <?php if($booking->status == 'Pending'): ?>
                                    <span class="badge bg-primary">Pending</span>
                                <?php elseif($booking->status == 'Ongoing'): ?>
                                    <span class="badge bg-warning">Ongoing</span>
                                <?php elseif($booking->status == 'Completed'): ?>
                                    <span class="badge bg-success">Completed</span>
                                <?php elseif($booking->status == 'Canceled'): ?>
                                    <span class="badge bg-danger">Canceled</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/frontend/bookings/index.blade.php ENDPATH**/ ?>