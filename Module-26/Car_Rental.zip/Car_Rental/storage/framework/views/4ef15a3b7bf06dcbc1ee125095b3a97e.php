<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Title with style -->
    <div class="text-center my-4">
        <h2 class="display-4 text-info">All Cars</h2>
        <p class="lead text-muted">Find the perfect vehicle for your next adventure</p>
    </div>

    <!-- Filter Form with refined style -->
    <form method="GET" action="<?php echo e(route('frontend.cars.index')); ?>" class="p-4 bg-light rounded shadow">
        <div class="row">
            <div class="form-group col-md-4">
                <label for="type" class="form-label text-primary">Car Type</label>
                <select class="form-control border-info" id="type" name="type">
                    <option value="">All</option>
                    <?php $__currentLoopData = $car_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->car_type); ?>" <?php if(request('type') == $type->car_type): ?> selected <?php endif; ?>><?php echo e($type->car_type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="brand" class="form-label text-primary">Brand</label>
                <select class="form-control border-info" id="brand" name="brand">
                    <option value="">All</option>
                    <?php $__currentLoopData = $car_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->brand); ?>" <?php if(request('brand') == $brand->brand): ?> selected <?php endif; ?>><?php echo e($brand->brand); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-md-4">
                <label for="search" class="form-label text-primary">Price Filter</label>
                <input class="form-control border-info" id="search" name="price" type="text" value="<?php echo e(request('price')); ?>" placeholder="Show vehicles under given price">
            </div>
        </div>
        <button class="btn btn-info w-100 mt-3" type="submit">Apply Filters</button>
    </form>

    <!-- Cars Listing -->
    <div class="row mt-4">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card mb-4 shadow-sm border-0" style="border-radius: 15px;">
                    <div class="d-flex align-items-center justify-content-evenly mx-2 p-3">
                        <div class="card-body">
                            <h5 class="card-title text-info"><?php echo e($car->brand); ?> - <?php echo e($car->car_type); ?></h5>
                            <h6 class="card-text">Daily Rent Price: <span class="text-success">$<?php echo e($car->daily_rent_price); ?></span></h6>
                            <a class="btn btn-outline-info" href="<?php echo e(route('frontend.cars.show', $car->id)); ?>">View Details</a>
                        </div>
                        <img class="img-thumbnail shadow" src="<?php echo e($car->image); ?>" alt="<?php echo e($car->brand); ?> - <?php echo e($car->car_type); ?>" style="height: 150px; width: 180px; object-fit: cover; border-radius: 10px;">                    
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/frontend/cars/index.blade.php ENDPATH**/ ?>