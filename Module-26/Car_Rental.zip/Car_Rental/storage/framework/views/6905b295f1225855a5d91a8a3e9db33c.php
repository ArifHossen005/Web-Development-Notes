<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>Add Rental</h2>

    <div class="d-flex justify-content-around align-items-center my-5 rounded p-2 shadow">
        <div>
            <h3><?php echo e($car->brand); ?></h3>
            <p>Model: <?php echo e($car->model); ?></p>
            <p>Daily Rent Price: <span class="font-weight-bold">$ <?php echo e($car->daily_rent_price); ?></span></p>
            <p>Year: <?php echo e($car->year); ?></p>
            <p>Type: <?php echo e($car->car_type); ?></p>
        </div>
        <div>
            <img class="img-thumbnail" src="<?php echo e(asset($car->image)); ?>" alt="<?php echo e($car->brand); ?> - <?php echo e($car->car_type); ?>" style="height: 180px;">
        </div>
    </div>

    <div class="rounded p-2 shadow">
        <form id="front_rental_form" action="<?php echo e(route('admin.rentals.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input name="car_id" type="hidden" value="<?php echo e($car->id); ?>">
            <div class="row gap-2">
                <div class="form-group">
                    <label for="user_id">Customer</label>
                    <select class="form-control" id="user_id" name="user_id" required>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>" <?php echo e(old('user_id') == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="start_date">Start Date</label>
                    <input class="form-control" id="start_date" name="start_date" type="text" value="<?php echo e(old('start_date')); ?>" required>
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <input class="form-control" id="end_date" name="end_date" type="text" value="<?php echo e(old('end_date')); ?>" required>
                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="total_cost">Total Cost (Optional)</label>
                    <input class="form-control" id="total_cost" name="total_cost" type="number" value="<?php echo e(old('total_cost')); ?>">
                    <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option selected>Select an option</option>
                        <option value="Pending" <?php echo e(old('status') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Ongoing" <?php echo e(old('status') == 'Ongoing' ? 'selected' : ''); ?>>Ongoing</option>
                        <option value="Completed" <?php echo e(old('status') == 'Completed' ? 'selected' : ''); ?>>Completed</option>
                        <option value="Canceled" <?php echo e(old('status') == 'Canceled' ? 'selected' : ''); ?>>Canceled</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <button class="btn btn-outline-success mt-2" id="submitBtn" type="submit">Add Rental</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            var unavailableDates = <?php echo json_encode($unavailableDates, 15, 512) ?>;

            function disableDates(date) {
                var today = new Date();
                today.setHours(0, 0, 0, 0);
                var string = jQuery.datepicker.formatDate('yy-mm-dd', date);

                if (date < today || unavailableDates.indexOf(string) != -1) {
                    return [false];
                } else {
                    return [true];
                }
            }

            $("#start_date, #end_date").datepicker({
                dateFormat: 'yy-mm-dd',
                beforeShowDay: disableDates
            });

            $('#front_rental_form').on('submit', function() {
                $('#submitBtn').prop('disabled', true);
                $('#submitBtn').html('Processing...');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Final Assignment\Project\resources\views/admin/rentals/create.blade.php ENDPATH**/ ?>