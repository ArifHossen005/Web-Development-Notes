<?php $__env->startSection('content'); ?>
    <h2>Edit Car</h2>
    <hr>
    <form action="<?php echo e(route('admin.cars.update', $car->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group mb-2">
            <label class="form-label" for="name">Car Name</label>
            <input class="form-control" id="name" name="name" type="text" value="<?php echo e($car->name); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="brand">Brand</label>
            <input class="form-control" id="brand" name="brand" type="text" value="<?php echo e($car->brand); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="model">Model</label>
            <input class="form-control" id="model" name="model" type="text" value="<?php echo e($car->model); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="year">Year of Manufacture</label>
            <input class="form-control" id="year" name="year" type="number" value="<?php echo e($car->year); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="car_type">Car Type</label>
            <input class="form-control" id="car_type" name="car_type" type="text" value="<?php echo e($car->car_type); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="daily_rent_price">Daily Rent Price</label>
            <input class="form-control" id="daily_rent_price" name="daily_rent_price" type="number" value="<?php echo e($car->daily_rent_price); ?>" required>
        </div>

        <div class="form-group mb-2">
            <label class="form-label" for="availability">Availability</label>
            <select class="form-control" id="availability" name="availability" required>
                <option value="1" <?php echo e($car->availability == 1 ? 'selected' : ''); ?>>Available</option>
                <option value="0" <?php echo e($car->availability == 0 ? 'selected' : ''); ?>>Not Available</option>
            </select>
        </div>

        <div class="mb-2">
            <label class="form-label" for="formFile">Select Car Image</label>
            <input class="form-control" id="image" name="image" type="file">
        </div>

        <button class="btn btn-outline-success" type="submit">Update Car</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/admin/cars/edit.blade.php ENDPATH**/ ?>