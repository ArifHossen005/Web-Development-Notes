<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <h3>Car Rental Confirmation of ID #<?php echo e($mail_data['id']); ?></h3>
    <p>Dear <?php echo e($mail_data['name']); ?>,</p>
    <p>Thank you for renting a car with us. Here are the details of your rental:</p>
    <ul>
        <li><strong>Car Name:</strong> <?php echo e($mail_data['car_name']); ?></li>
        <li><strong>Car brand:</strong> <?php echo e($mail_data['car_brand']); ?></li>
        <li><strong>Car Model:</strong> <?php echo e($mail_data['car_model']); ?></li>
        <li><strong>Car Type:</strong> <?php echo e($mail_data['car_type']); ?></li>
        <li><strong>Car YOM:</strong> <?php echo e($mail_data['car_year']); ?></li>
        <li><strong>Rental Start Date:</strong> <?php echo e($mail_data['start_date']); ?></li>
        <li><strong>Rental End Date:</strong> <?php echo e($mail_data['end_date']); ?></li>
        <li><strong>Total Cost:</strong> $<?php echo e($mail_data['total_cost']); ?></li>
    </ul>
    <p>If you have any questions, feel free to contact us.</p>
    <p>Best regards,</p>
    <p>Laravel Car Rental APP &#128512;</p>
</body>

</html>
<?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/email/customer-notify.blade.php ENDPATH**/ ?>