<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>

    <h2 align="center">Rentals</h2>
    
    <table class="table-bordered table">
        <thead>
            <tr>
                <th>Rental ID</th>
                <th>Customer Name</th>
                <th>Car Details (Name, Brand)</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Total Cost</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rental->id); ?></td>
                    <td><?php echo e($rental->user->name); ?></td>
                    <td><?php echo e($rental->car->name); ?> (<?php echo e($rental->car->brand); ?>)</td>
                    <td><?php echo e($rental->start_date); ?></td>
                    <td><?php echo e($rental->end_date); ?></td>
                    <td><?php echo e($rental->total_cost); ?></td>
                    <td><?php echo e($rental->status); ?></td>
                    <td>
                        <a class="btn btn-outline-warning btn-sm" href="<?php echo e(route('admin.rentals.edit', $rental->id)); ?>">Edit</a>
                        <form style="display:inline;" action="<?php echo e(route('admin.rentals.destroy', $rental->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger btn-sm" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($rentals->links()); ?>


    <hr>

    <div class="mt-4">
        <table class="table-bordered table">
            <thead>
                <tr>
                    <th>Brand</th>
                    <th>Car Type</th>
                    <th>Daily Rent Price</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($car->brand); ?></td>
                        <td><?php echo e($car->car_type); ?></td>
                        <td>$<?php echo e($car->daily_rent_price); ?></td>
                        <td><img class="img-thumbnail" src="<?php echo e(asset($car->image)); ?>" alt="<?php echo e($car->brand); ?> - <?php echo e($car->car_type); ?>" style="height: 100px; width: 120px;"></td>
                        
                        
                        <td>
                            <a class="btn btn-outline-success" href="<?php echo e(route('admin.rentals.create', ['id' => $car->id])); ?>">Make New Rental</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/admin/rentals/index.blade.php ENDPATH**/ ?>