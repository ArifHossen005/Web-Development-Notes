<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>Cars</h2>
    <a class="btn btn-outline-success mb-3" href="<?php echo e(route('admin.cars.create')); ?>">Add Car</a>

    <table class="table-bordered table">
        <thead>
            <tr>
                <th>SL NO</th>
                <th>Car Name</th>
                <th>Brand</th>
                <th>Model</th>
                <th>Year of Manufacture</th>
                <th>Car Type</th>
                <th>Daily Rent Price</th>
                <th>Availability Status</th>
                <th>Car Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($car->id); ?></td>
                    <td><?php echo e($car->name); ?></td>
                    <td><?php echo e($car->brand); ?></td>
                    <td><?php echo e($car->model); ?></td>
                    <td><?php echo e($car->year); ?></td>
                    <td><?php echo e($car->car_type); ?></td>
                    <td><?php echo e($car->daily_rent_price); ?></td>
                    <td><?php echo e($car->availability ? 'Available' : 'Not Available'); ?></td>
                    <td><img class="img-thumbnail" src="<?php echo e(asset($car->image)); ?>" alt="<?php echo e($car->name); ?>" style="width: 80px;"></td>
                    <td>
                        <a class="btn btn-outline-warning btn-sm" href="<?php echo e(route('admin.cars.edit', $car->id)); ?>">Edit</a>
                        <form style="display:inline;" action="<?php echo e(route('admin.cars.destroy', $car->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger btn-sm" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Final Assignment\Car_Rental\resources\views/admin/cars/index.blade.php ENDPATH**/ ?>