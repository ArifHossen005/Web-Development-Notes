<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>Customers</h2>
    <a class="btn btn-outline-success mb-3" href="<?php echo e(route('admin.customers.create')); ?>">Add Customer</a>
    <table class="table-bordered table">
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->phone); ?></td>
                    <td><?php echo e($customer->address); ?></td>
                    <td>
                        <a class="btn btn-outline-warning btn-sm" href="<?php echo e(route('admin.customers.edit', $customer->id)); ?>">Edit</a>
                        <form style="display:inline;" action="<?php echo e(route('admin.customers.destroy', $customer->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-outline-danger btn-sm" type="submit">Delete</button>
                        </form>
                        <a class="btn btn-outline-info btn-sm" href="<?php echo e(route('admin.customers.show', $customer->id)); ?>">View Rentals</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Final Assignment\Project\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>