<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials._alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-12 mt-4">
    <div class="row p-4 shadow-sm rounded bg-light">
        <!-- Car Details Section -->
        <div class="col-md-6">
            <h3 class="text-info"><?php echo e($car->brand); ?></h3>
            <p><strong>Model:</strong> <?php echo e($car->model); ?></p>
            <p><strong>Daily Rent Price:</strong> <span class="font-weight-bold text-success">$ <?php echo e($car->daily_rent_price); ?></span></p>
            <p><strong>Year:</strong> <?php echo e($car->year); ?></p>
            <p><strong>Type:</strong> <?php echo e($car->car_type); ?></p>
            <img class="img-thumbnail my-2" src="<?php echo e(asset($car->image)); ?>" alt="<?php echo e($car->brand); ?> - <?php echo e($car->car_type); ?>" style="width: 50%; border-radius: 10px; object-fit: cover;">
        </div>

        <!-- Booking Form Section -->
        <div class="col-md-6">
            <div class="p-4 shadow-lg rounded bg-white">
                <form id="front_rental_form" action="<?php echo e(route('frontend.rentals.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="car_id" type="hidden" value="<?php echo e($car->id); ?>">

                    <div class="row g-3">
                        <div class="form-group">
                            <label for="start_date" class="form-label">Start Date</label>
                            <input class="form-control border-info" id="start_date" name="start_date" type="text" required>
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="end_date" class="form-label">End Date</label>
                            <input class="form-control border-info" id="end_date" name="end_date" type="text" required>
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <button class="btn btn-outline-info mt-3 w-100" id="submitBtn" type="submit">Book Now</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            var unavailableDates = <?php echo json_encode($unavailableDates, 15, 512) ?>;

            function disableDates(date) {
                var today = new Date();
                today.setHours(0, 0, 0, 0);
                var string = jQuery.datepicker.formatDate('yy-mm-dd', date);

                if (date < today || unavailableDates.indexOf(string) != -1) {
                    return [false];
                } else {
                    return [true];
                }
            }

            $("#start_date, #end_date").datepicker({
                dateFormat: 'yy-mm-dd',
                beforeShowDay: disableDates
            });

            $('#front_rental_form').on('submit', function() {
                $('#submitBtn').prop('disabled', true);
                $('#submitBtn').html('Processing...');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Downloads\Compressed\Project\resources\views/frontend/cars/show.blade.php ENDPATH**/ ?>